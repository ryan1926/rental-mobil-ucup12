(function($) {
    "use strict"

    new quixSettings({
        sidebarStyle: "mini"
    });


})(jQuery);