<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Rental Mobil - <?php echo $__env->yieldContent('title'); ?> </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/owl-carousel/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/owl-carousel/css/owl.theme.default.min.css')); ?>">
    <link href="<?php echo e(asset('assets/vendor/jqvmap/css/jqvmap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

    <!-- DataTable -->
     <link href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.css" rel="stylesheet">
     <link rel="stylesheet" href="https://cdn.datatables.net/rowreorder/1.5.0/css/rowReorder.dataTables.css">
     <link rel="stylesheet" href="https://cdn.datatables.net/responsive/3.0.3/css/responsive.dataTables.css">



</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="index.html" class="brand-logo">
                <img class="logo-abbr" src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
                <img class="logo-compact" src="<?php echo e(asset('assets/images/logo-text.png')); ?>" alt="">
                <img class="brand-title" src="<?php echo e(asset('assets/images/logo-text.png')); ?>" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo e(asset('assets/vendor/global/global.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/quixnav-init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.min.js')); ?>"></script>


    <!-- Vectormap -->
    <script src="<?php echo e(asset('assets/vendor/raphael/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/morris/morris.min.js')); ?>"></script>


    <script src="<?php echo e(asset('assets/vendor/circle-progress/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/chart.js/Chart.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/vendor/gaugeJS/dist/gauge.min.js')); ?>"></script>

    <!--  flot-chart js -->
    <script src="<?php echo e(asset('assets/vendor/flot/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/flot/jquery.flot.resize.js')); ?>"></script>

    <!-- Owl Carousel -->
    <script src="<?php echo e(asset('assets/vendor/owl-carousel/js/owl.carousel.min.js')); ?>"></script>

    <!-- Counter Up -->
    <script src="<?php echo e(asset('assets/vendor/jqvmap/js/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/jqvmap/js/jquery.vmap.usa.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/jquery.counterup/jquery.counterup.min.js')); ?>"></script>


    <script src="<?php echo e(asset('assets/js/dashboard/dashboard-1.js')); ?>"></script>

    <!-- Datatable responsive Mobile -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/rowreorder/1.5.0/js/dataTables.rowReorder.js"></script>
    <script src="https://cdn.datatables.net/rowreorder/1.5.0/js/rowReorder.dataTables.js"></script>
    <script src="https://cdn.datatables.net/responsive/3.0.3/js/dataTables.responsive.js"></script>
    <script src="https://cdn.datatables.net/responsive/3.0.3/js/responsive.dataTables.js"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH D:\rental\resources\views/layouts/main.blade.php ENDPATH**/ ?>