
<?php $__env->startSection('title', 'Riwayat transaksi'); ?>
<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
  <div class="row page-titles mx-0">
    <div class="col-sm-6 p-md-0">
      <div class="welcome-text">
        <h4>Rental Mobil -> <?php echo e($rentalMobil->nama_rental); ?></h4>
        <center>
    <img calss=" card-img-top img-fluid m-4" src="<?php echo e(asset('/storage/' . $rentalMobil->foto)); ?>" alt="foto" style="widt: auto; height: 300px;"> 
   </center>

    <p class=" card-text text-dark"><?php echo e($rentalMobil->deskripsi); ?></p>

      </div>
    </div>
  </div>

  <div class="row">
    <?php $__currentLoopData = $mobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xl-4 col-xxl-6 col-lg-6 col-sm-6">
      <div class="card mb-3">
        <img
        class="card-img-top img-fluid"
        src="<?php echo e(asset('/storage/' . $mobil->foto)); ?>"
        alt="Card image cap"
        />
      <div class="card-header">
        <h5 class="card-title"><?php echo e($mobil->merek); ?></h5>
      </div>
      <div class="card-body">
        <p class="card-text text-dark">
          Alamat: <?php echo e($mobil->rentalMobil->alamat); ?>

        </p>
        <p class="card-text text-dark">
          Kontak Owner: <?php echo e($mobil->rentalMobil->no_hp); ?> / <a href= "<?php echo e(route('rental.view',$mobil->rentalMobil->id)); ?>"><?php echo e($mobil->rentalMobil->nama_rental); ?></a>
        </p>
        <a href="<?php echo e(route('booking.mobil', $mobil->id)); ?>" class="btn btn-primary float-right">Check</a>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\rental\resources\views/rentalMobil.blade.php ENDPATH**/ ?>