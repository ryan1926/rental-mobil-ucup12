<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<?php
    $rolesUser = [];
    if (auth()->user()){
        foreach (auth()->user()->roles as $item) {
            array_push($rolesUser, $item->kode_role);
        }
    }
?>

<?php if(in_array('SAD', $rolesUser)): ?>
    <?php
        $user = App\Models\User::count();
        $rentalMobil = App\Models\RentalMobil::count();
    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Pengguna</div>
                            <div class="stat-digit"><i class="fa fa-user"></i> <?php echo e($user); ?></div>
                        </div>
                        <div class="progress">
                            <div class="progress-bar progress-bar-success w-85" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6">
                <div class="card">
                    <div class="stat-widget-two card-body">
                        <div class="stat-content">
                            <div class="stat-text">Rental Mobil</div>
                            <div class="stat-digit"><i class="fa fa-car"></i> <?php echo e($rentalMobil); ?></div>
                        </div>
                        <div class="progress">
                            <div class="progress-bar progress-bar-primary w-75" role="progressbar" aria-valuenow="78" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php elseif(in_array('ADM', $rolesUser)): ?>
<?php
$mobils= App\Models\Mobil::Where('rental_mobil_id', auth()->user()->rentalMobil->id)
->latest()
->get();
?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Data Mobil</h4>
            </div>
            <div class="card-body">
                <a href="<?php echo e(route('mobil.create')); ?>" class="btn btn-primary">Create</a>
                <div class="table-responsive">
                    <table id="table-mobil" class="display nowrap text-dark" style="width:100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Merek</th>
                                <th>Plat Nomor</th>
                                <th>Warna</th>
                                <th>Foto</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($mobil->merek); ?></td>
                                    <td><?php echo e($mobil->plat_nomor); ?></td>
                                    <td><?php echo e($mobil->warna); ?></td>
                                    <td><img src="<?php echo e(asset('/storage/' . $mobil->foto)); ?>" alt="foto" style="width: 100px; height: 100px;"></td>
                                    <td>
                                        <?php if($mobil->checkStatus($mobil->id)): ?>
                                            <?php if($mobil->checkStatus($mobil->id)->status == 'selesai'): ?>
                                                <span class="badge badge-pill badge-success">Ready</span>
                                            <?php elseif($mobil->checkStatus($mobil->id)->status == 'Pending'): ?>
                                                <span class="badge badge-pill badge-primary">Sedang di Booking</span>
                                            <?php elseif($mobil->checkStatus($mobil->id)->status == 'Berjalan'): ?>
                                                <span class="badge badge-pill badge-secondary">Sedang di Rental</span>
                                                <?php else: ?>
                                                <span class="badge badge-pill badge-success">Ready</span>
                                            <?php endif; ?>
                                      
                                            
                                        <?php endif; ?>
                                      
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No</th>
                                <th>Merek</th>
                                <th>Plat Nomor</th>
                                <th>Warna</th>
                                <th>Foto</th>
                                <th>Aksi</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
</div>


<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#table-mobil', {
            responsive: true,
            rowReorder: {
                selector: 'td:nth-child(2)'
            }
        });
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\rental\resources\views/dashboard.blade.php ENDPATH**/ ?>