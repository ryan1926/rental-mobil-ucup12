

<?php $__env->startSection('title', 'Booking'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="Welcome-text">
                <span class="ml-1">Booking</span>
            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Mobil</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Create</a></li>
            </ol>
        </div>
    </div>

    <!-- Alert for Errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-warning alert-dismissible alert-alt solid fade show">
            <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
            </button>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><strong>Warning!</strong> <?php echo e($error); ?>. Silahkan Cek Kembali.</li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Alert for Success -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible alert-alt solid fade show">
            <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
            </button>
            <li><strong>Success!</strong> <?php echo e(session('success')); ?>. Silahkan Cek Kembali.</li>
        </div>
    <?php endif; ?>

    <!-- Alert for Warning -->
    <?php if(session('warning')): ?>
        <div class="alert alert-warning alert-dismissible alert-alt solid fade show">
            <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
            </button>
            <li><strong>Warning!</strong> <?php echo e(session('warning')); ?>. Silahkan Cek Kembali.</li>
        </div>
    <?php endif; ?>

    <!-- Form for Booking -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Booking Area</h4>
                </div>
                <div class="card-body">
                    <div class="basic-form text-dark">
                        <form action="<?php echo e(route('booking.proses',$id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <!-- Tanggal Peminjaman -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Mulai</label>
                                <div class="col-sm-10">
                                    <input type="datetime-local" class="form-control" name="tgl_peminjaman" value="<?php echo e(old('tgl_peminjaman')); ?>" required>
                                </div>
                            </div>

                            <!-- Tanggal Pengembalian -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Pengembalian</label>
                                <div class="col-sm-10">
                                    <input type="datetime-local" class="form-control" name="tgl_pengembalian" value="<?php echo e(old('tgl_pengembalian')); ?>" required>
                                </div>
                            </div>

                            <!-- Submit Button -->
                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-primary">Booking</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/l/rental/resources/views/transaksi/booking.blade.php ENDPATH**/ ?>