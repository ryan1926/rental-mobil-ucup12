<div class="header">
    <div class="header-content">
        <nav class="navbar navbar-expand">
            <div class="collapse navbar-collapse justify-content-between">
                <div class="header-left">
                    
                </div>
<?php if(auth()->guard()->check()): ?>
                <ul class="navbar-nav header-right">
                    
                    <li class="nav-item dropdown header-profile">
                        <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                            <i class="mdi mdi-account"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                        <a href="<?php echo e(route('users.profile', auth()->user()->id)); ?>" class="dropdown-item">
                                <i class="icon-user"></i>
                                <span class="ml-2">Profil </span>
                            </a>
                            <a href="<?php echo e(route('auth.logout')); ?>" class="dropdown-item">
                                <i class="icon-key"></i>
                                <span class="ml-2">Logout </span>
                            </a>
                        </div>
                    </li>
                </ul>
                <?php else: ?>
                <div class="header-leaft">
                    <a href="<?php echo e((route('auth.login'))); ?>" class="btn btn-primary">login</a>
            </div>
            <?php endif; ?>
                    </div>
        </nav>
    </div>
</div><?php /**PATH D:\rental\resources\views/layouts/header.blade.php ENDPATH**/ ?>