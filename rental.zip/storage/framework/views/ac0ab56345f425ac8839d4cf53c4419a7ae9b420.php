<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>

    

    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="Welcome-text">
                    <span class="ml-1">Create</span>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Mobil</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Create</a></li>
                </ol>
            </div>
        </div>


        <?php if($errors->any()): ?>
            <div class="alert alert-warning alert-dismissible alert-alt solid fade show">
                <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i
                            class="mdi mdi-close"></i></span>
                </button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><strong>Warning!</strong> <?php echo e($error); ?>. Silahkan Cek
                            Kembali.</li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible alert-alt solid fade show">
                <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i
                            class="mdi mdi-close"></i></span>
                </button>
                <li><strong>Success!</strong> <?php echo e(session('success')); ?>. Silahkan Cek
                    Kembali.</li>
            </div>
        <?php endif; ?>

        <?php if(session('warning')): ?>
            <div class="alert alert-warning alert-dismissible alert-alt solid fade show">
                <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i
                            class="mdi mdi-close"></i></span>
                </button>
                <li><strong>Warning!</strong> <?php echo e(session('warning')); ?>. Silahkan Cek
                    Kembali.</li>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Profile</h4>
                    </div>
                    <div class="card-body">
                        <div class="basic-form text-dark">
                            <form action="<?php echo e(route('mobil.create')); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                              
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label">Merek</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="merek"
                                                value="<?php echo e(old('merek')); ?>" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label">Warna</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="warna"
                                                value="<?php echo e(old('warna')); ?>" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label">Plat Nomor</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" name="plat_nomor"
                                                value="<?php echo e(old('plat_nomor')); ?>" required>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label">Foto</label>
                                        <div class="col-sm-10">
                                            <input type="file" class="form-control" name="foto" required>
                                        </div>
                                    </div>
                                            

                                <div class="form-group row">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/l/rental/resources/views/mobil/create.blade.php ENDPATH**/ ?>