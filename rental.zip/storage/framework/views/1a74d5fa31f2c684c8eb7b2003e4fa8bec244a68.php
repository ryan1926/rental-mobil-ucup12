

<?php $__env->startSection('title', 'Riwayat transaksi'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <span class="ml-1">Riwayat transaksi</span>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Riwayat</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="table-users" class="display nowrap text-dark" style="width:100%">
                            <?php
                            $rolesUser = [];
                            if (auth()->user()) {
                                foreach (auth()->user()->roles as $item) {
                                    array_push($rolesUser, $item->kode_role);
                                }
                            }
                            ?>
                            
                            <?php if(in_array('ADM', $rolesUser)): ?>
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Merek</th>
                                        <th>Plat nomor</th>
                                        <th>Warna</th>
                                        <th>Foto</th>
                                        <th>Customer</th>
                                        <th>No Hp</th>
                                        <th>Tgl Peminjaman</th>
                                        <th>Tgl Pengembalian</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $riwayats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($riwayat->mobil->merek); ?></td>
                                            <td><?php echo e($riwayat->mobil->plat_nomor); ?></td>
                                            <td><?php echo e($riwayat->mobil->warna); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset('/storage/' . $riwayat->mobil->foto)); ?>" alt="foto" style="width: 100px; height: 100px;">
                                            </td>
                                            <td><?php echo e($riwayat->user->konsumen->nama); ?></td>
                                            <td><?php echo e($riwayat->user->konsumen->no_hp); ?></td>
                                            <td><?php echo e($riwayat->tgl_peminjaman); ?></td>
                                            <td><?php echo e($riwayat->tgl_pengembalian); ?></td>
                                            <td><?php echo e($riwayat->status); ?></td>
                                            <td>
                                                <?php if($riwayat->status == 'pending'): ?>
                                                    <a href="<?php echo e(route('approve', $riwayat->id)); ?>" class="btn btn-success">Approve</a>
                                                <?php elseif($riwayat->status == 'Berjalan'): ?>
                                                    <a href="<?php echo e(route('approve', $riwayat->id)); ?>" class="btn btn-primary">Selesai</a>
                                                <?php else: ?>
                                                    <span>Tidak ada aksi</span>

                                                    
                                                
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>No</th>
                                        <th>Merek</th>
                                        <th>Plat nomor</th>
                                        <th>Warna</th>
                                        <th>Foto</th>
                                        <th>Customer</th>
                                        <th>No Hp</th>
                                        <th>Tgl Peminjaman</th>
                                        <th>Tgl Pengembalian</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                            <?php elseif(in_array('CST', $rolesUser)): ?>
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Merek</th>
                                        <th>Plat nomor</th>
                                        <th>Warna</th>
                                        <th>Foto</th>
                                        <th>Tgl Peminjaman</th>
                                        <th>Tgl Pengembalian</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $riwayats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($riwayat->mobil->merek); ?></td>
                                            <td><?php echo e($riwayat->mobil->plat_nomor); ?></td>
                                            <td><?php echo e($riwayat->mobil->warna); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset('/storage/' . $riwayat->mobil->foto)); ?>" alt="foto" style="width: 100px; height: 100px;">
                                            </td>
                                            <td><?php echo e($riwayat->tgl_peminjaman); ?></td>
                                            <td><?php echo e($riwayat->tgl_pengembalian); ?></td>
                                            <td><?php echo e($riwayat->status); ?></td>
                                            <td>
                                            <?php if($riwayat->status == 'pending'): ?>
                                             <form action="<?php echo e(route('booking.batalkan', $riwayat->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                  <button class="btn btn-warning" onclick="return confirm('Anda yakin batal ini?')">Batalkan</button>
                                                  </form>
                                            <?php else: ?>
                                           
                                                tidak ada aksi   
                                            <?php endif; ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>No</th>
                                        <th>Merek</th>
                                        <th>Plat nomor</th>
                                        <th>Warna</th>
                                        <th>Foto</th>
                                        <th>Tgl Peminjaman</th>
                                        <th>Tgl Pengembalian</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->startPush('scripts'); ?>
<script>
    new DataTable('#table-users', {
        responsive: true,
        rowReorder: {
            selector: 'td:nth-child(2)'
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\rental\resources\views/transaksi/riwayat.blade.php ENDPATH**/ ?>