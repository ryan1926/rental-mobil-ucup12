<?php $__env->startSection('title', 'Mobil'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <span class="ml-1">Mobil</span>
                </div>
            </div>
                        <!-- <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Table</a></li>
                                <li class="breadcrumb-item active"><a href="javascript:void(0)">Datatable</a></li>
                            </ol>
                        </div> -->
        </div>
                    <!-- row -->
                            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible alert-alt solid fade show">
                <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i
                            class="mdi mdi-close"></i></span>
                </button>
                <li><strong>Success!</strong> <?php echo e(session('success')); ?>. Silahkan Cek
                    Kembali.</li>
            </div>
        <?php endif; ?>


        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Data mobil</h4>
                    </div>
                    <div class="card-body">
                      <a href="<?php echo e(route('mobil.create')); ?>" class="btn btn-primary">Create</a>
                        <div class="table-responsive">
                            <table id="table-mobil" class="display nowrap text-dark" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Merek</th>
                                        <th>Plat Nomor</th>
                                        <th>Warna</th>
                                        <th>Foto</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $mobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($mobil->merek); ?></td>
                                             <td><?php echo e($mobil->plat_nomor); ?></td>
                                             <td><?php echo e($mobil->warna); ?></td>
                                             <td><img src="<?php echo e(asset('/storage/'. $mobil->foto)); ?>" alt="foto" style="width: 100px; height: 100px;"> 
                                             </td>
                                             <td>
                                             <form action="<?php echo e(route('mobil.delete', $mobil->id)); ?>" method="post">
                                               <?php echo csrf_field(); ?>
                                               <?php echo method_field('delete'); ?>
                                               <a href="<?php echo e(route('mobil.edit', $mobil->id)); ?>"
                                               class="btn btn-warning">Edit</a>
                                               <button class="btn btn-danger" onclick="return confirm('anda yakin hapus data ini')">Delete</button>
                                             </form>
                                             </td>
                                        </tr> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>No</th>
                                        <th>Merek</th>
                                        <th>Plat Nomor</th>
                                        <th>Warna</th>
                                        <th>Foto</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#table-mobil', {
            responsive: true,
            rowReorder: {
                selector: 'td:nth-child(2)'
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/emulated/0/l/rental/resources/views/mobil/index.blade.php ENDPATH**/ ?>